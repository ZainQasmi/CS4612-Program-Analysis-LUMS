# Generated from myGrammar.g4 by ANTLR 4.7
# encoding: utf-8
from __future__ import print_function
from antlr4 import *
from io import StringIO
import sys

def serializedATN():
    with StringIO() as buf:
        buf.write(u"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3")
        buf.write(u"\67\u0096\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7")
        buf.write(u"\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\4\r\t")
        buf.write(u"\r\3\2\3\2\5\2\35\n\2\3\2\3\2\7\2!\n\2\f\2\16\2$\13\2")
        buf.write(u"\3\2\3\2\3\3\3\3\3\4\3\4\3\4\3\4\3\4\3\4\3\5\3\5\3\5")
        buf.write(u"\3\5\3\5\3\5\3\5\5\5\67\n\5\3\6\3\6\3\6\3\6\3\6\3\6\3")
        buf.write(u"\6\3\6\3\6\3\6\3\6\3\6\3\6\5\6F\n\6\3\7\3\7\3\7\3\7\7")
        buf.write(u"\7L\n\7\f\7\16\7O\13\7\3\7\3\7\3\b\3\b\3\b\7\bV\n\b\f")
        buf.write(u"\b\16\bY\13\b\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\5\tc\n")
        buf.write(u"\t\3\n\3\n\3\13\6\13h\n\13\r\13\16\13i\3\13\3\13\3\f")
        buf.write(u"\3\f\3\f\3\f\3\f\3\f\3\f\3\f\3\f\3\f\3\f\5\fy\n\f\3\f")
        buf.write(u"\3\f\3\f\3\f\3\f\3\f\3\f\3\f\3\f\7\f\u0084\n\f\f\f\16")
        buf.write(u"\f\u0087\13\f\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r")
        buf.write(u"\3\r\5\r\u0094\n\r\3\r\2\3\26\16\2\4\6\b\n\f\16\20\22")
        buf.write(u"\24\26\30\2\6\3\2&\'\4\2\37\"$%\3\2\33\34\3\2\31\32\2")
        buf.write(u"\u00a0\2\32\3\2\2\2\4\'\3\2\2\2\6)\3\2\2\2\b\66\3\2\2")
        buf.write(u"\2\nE\3\2\2\2\fG\3\2\2\2\16R\3\2\2\2\20b\3\2\2\2\22d")
        buf.write(u"\3\2\2\2\24g\3\2\2\2\26x\3\2\2\2\30\u0093\3\2\2\2\32")
        buf.write(u"\34\7\26\2\2\33\35\5\26\f\2\34\33\3\2\2\2\34\35\3\2\2")
        buf.write(u"\2\35\"\3\2\2\2\36\37\7\16\2\2\37!\5\26\f\2 \36\3\2\2")
        buf.write(u"\2!$\3\2\2\2\" \3\2\2\2\"#\3\2\2\2#%\3\2\2\2$\"\3\2\2")
        buf.write(u"\2%&\7\27\2\2&\3\3\2\2\2\'(\t\2\2\2(\5\3\2\2\2)*\7\13")
        buf.write(u"\2\2*+\7\62\2\2+,\7\t\2\2,-\5\b\5\2-.\7\17\2\2.\7\3\2")
        buf.write(u"\2\2/\67\7\62\2\2\60\61\7\3\2\2\61\62\7\62\2\2\62\67")
        buf.write(u"\7\4\2\2\63\64\7\5\2\2\64\65\7\63\2\2\65\67\7\23\2\2")
        buf.write(u"\66/\3\2\2\2\66\60\3\2\2\2\66\63\3\2\2\2\67\t\3\2\2\2")
        buf.write(u"89\7\6\2\29:\7\62\2\2:;\5\22\n\2;<\5\26\f\2<=\7\17\2")
        buf.write(u"\2=F\3\2\2\2>?\7\7\2\2?F\7\17\2\2@A\7\b\2\2AB\7\62\2")
        buf.write(u"\2BC\5\22\n\2CD\5\26\f\2DF\3\2\2\2E8\3\2\2\2E>\3\2\2")
        buf.write(u"\2E@\3\2\2\2F\13\3\2\2\2GH\7\20\2\2HI\7\62\2\2IM\7\22")
        buf.write(u"\2\2JL\5\16\b\2KJ\3\2\2\2LO\3\2\2\2MK\3\2\2\2MN\3\2\2")
        buf.write(u"\2NP\3\2\2\2OM\3\2\2\2PQ\7\4\2\2Q\r\3\2\2\2RW\7\62\2")
        buf.write(u"\2ST\7\16\2\2TV\7\62\2\2US\3\2\2\2VY\3\2\2\2WU\3\2\2")
        buf.write(u"\2WX\3\2\2\2X\17\3\2\2\2YW\3\2\2\2Z[\5\26\f\2[\\\5\22")
        buf.write(u"\n\2\\]\5\26\f\2]c\3\2\2\2^_\7\22\2\2_`\5\20\t\2`a\7")
        buf.write(u"\23\2\2ac\3\2\2\2bZ\3\2\2\2b^\3\2\2\2c\21\3\2\2\2de\t")
        buf.write(u"\3\2\2e\23\3\2\2\2fh\5\30\r\2gf\3\2\2\2hi\3\2\2\2ig\3")
        buf.write(u"\2\2\2ij\3\2\2\2jk\3\2\2\2kl\7\2\2\3l\25\3\2\2\2mn\b")
        buf.write(u"\f\1\2no\7\22\2\2op\5\26\f\2pq\7\23\2\2qy\3\2\2\2ry\5")
        buf.write(u"\2\2\2sy\7\63\2\2ty\7\62\2\2uy\5\f\7\2vy\5\6\4\2wy\5")
        buf.write(u"\n\6\2xm\3\2\2\2xr\3\2\2\2xs\3\2\2\2xt\3\2\2\2xu\3\2")
        buf.write(u"\2\2xv\3\2\2\2xw\3\2\2\2y\u0085\3\2\2\2z{\f\13\2\2{|")
        buf.write(u"\7\36\2\2|\u0084\5\26\f\f}~\f\n\2\2~\177\t\4\2\2\177")
        buf.write(u"\u0084\5\26\f\13\u0080\u0081\f\t\2\2\u0081\u0082\t\5")
        buf.write(u"\2\2\u0082\u0084\5\26\f\n\u0083z\3\2\2\2\u0083}\3\2\2")
        buf.write(u"\2\u0083\u0080\3\2\2\2\u0084\u0087\3\2\2\2\u0085\u0083")
        buf.write(u"\3\2\2\2\u0085\u0086\3\2\2\2\u0086\27\3\2\2\2\u0087\u0085")
        buf.write(u"\3\2\2\2\u0088\u0089\7\62\2\2\u0089\u008a\7#\2\2\u008a")
        buf.write(u"\u008b\5\26\f\2\u008b\u008c\7\64\2\2\u008c\u0094\3\2")
        buf.write(u"\2\2\u008d\u008e\5\26\f\2\u008e\u008f\7\64\2\2\u008f")
        buf.write(u"\u0094\3\2\2\2\u0090\u0094\5\26\f\2\u0091\u0094\5\f\7")
        buf.write(u"\2\u0092\u0094\7\64\2\2\u0093\u0088\3\2\2\2\u0093\u008d")
        buf.write(u"\3\2\2\2\u0093\u0090\3\2\2\2\u0093\u0091\3\2\2\2\u0093")
        buf.write(u"\u0092\3\2\2\2\u0094\31\3\2\2\2\16\34\"\66EMWbix\u0083")
        buf.write(u"\u0085\u0093")
        return buf.getvalue()


class myGrammarParser ( Parser ):

    grammarFileName = "myGrammar.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ u"<INVALID>", u"'range(len('", u"'):'", u"'range('", 
                     u"'if'", u"'else'", u"'elif'", u"'in'", u"'as'", u"'for'", 
                     u"'while'", u"'&&'", u"','", u"':'", u"'def'", u"'return'", 
                     u"'('", u"')'", u"'{'", u"'}'", u"'['", u"']'", u"'not'", 
                     u"'+'", u"'-'", u"'*'", u"'/'", u"'%'", u"'^'", u"'>'", 
                     u"'>='", u"'<'", u"'<='", u"'='", u"'=='", u"'!='", 
                     u"'true'", u"'false'", u"'len'", u"'print'", u"'append'", 
                     u"'open'", u"'+='", u"'-='", u"'*='", u"'/='", u"'or'", 
                     u"'and'", u"<INVALID>", u"<INVALID>", u"'\n'", u"<INVALID>", 
                     u"'#'", u"'\t'" ]

    symbolicNames = [ u"<INVALID>", u"<INVALID>", u"<INVALID>", u"<INVALID>", 
                      u"IF", u"ELSE", u"ELIF", u"IN", u"AS", u"FOR", u"WHILE", 
                      u"ANDAND", u"COMMA", u"COLON", u"DEF", u"RET", u"LPAREN", 
                      u"RPAREN", u"LBRACE", u"RBRACE", u"LBRACK", u"RBRACK", 
                      u"NOT", u"PLUS", u"MINUS", u"MULTIPLY", u"DIVIDE", 
                      u"MOD", u"POWER", u"GT", u"GE", u"LT", u"LE", u"ASSIGNMENT", 
                      u"EQUAL", u"NOTEQUAL", u"TRUE", u"FALSE", u"LENGTH", 
                      u"PRINT", u"APPEND", u"OPEN", u"PLUSEQUAL", u"MINUSEQUAL", 
                      u"MULTEQUAL", u"DIVEQUAL", u"OR", u"AND", u"ID", u"NUMBER", 
                      u"NEWLINE", u"WS", u"COMMENT", u"INDENT" ]

    RULE_lists = 0
    RULE_boolean = 1
    RULE_forRule = 2
    RULE_forconstruct = 3
    RULE_ifRule = 4
    RULE_functionDef = 5
    RULE_parameters = 6
    RULE_comparison = 7
    RULE_comp_oper = 8
    RULE_rules = 9
    RULE_expression = 10
    RULE_statement = 11

    ruleNames =  [ u"lists", u"boolean", u"forRule", u"forconstruct", u"ifRule", 
                   u"functionDef", u"parameters", u"comparison", u"comp_oper", 
                   u"rules", u"expression", u"statement" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    IF=4
    ELSE=5
    ELIF=6
    IN=7
    AS=8
    FOR=9
    WHILE=10
    ANDAND=11
    COMMA=12
    COLON=13
    DEF=14
    RET=15
    LPAREN=16
    RPAREN=17
    LBRACE=18
    RBRACE=19
    LBRACK=20
    RBRACK=21
    NOT=22
    PLUS=23
    MINUS=24
    MULTIPLY=25
    DIVIDE=26
    MOD=27
    POWER=28
    GT=29
    GE=30
    LT=31
    LE=32
    ASSIGNMENT=33
    EQUAL=34
    NOTEQUAL=35
    TRUE=36
    FALSE=37
    LENGTH=38
    PRINT=39
    APPEND=40
    OPEN=41
    PLUSEQUAL=42
    MINUSEQUAL=43
    MULTEQUAL=44
    DIVEQUAL=45
    OR=46
    AND=47
    ID=48
    NUMBER=49
    NEWLINE=50
    WS=51
    COMMENT=52
    INDENT=53

    def __init__(self, input, output=sys.stdout):
        super(myGrammarParser, self).__init__(input, output=output)
        self.checkVersion("4.7")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None



    class ListsContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(myGrammarParser.ListsContext, self).__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(myGrammarParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(myGrammarParser.ExpressionContext,i)


        def getRuleIndex(self):
            return myGrammarParser.RULE_lists

        def enterRule(self, listener):
            if hasattr(listener, "enterLists"):
                listener.enterLists(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitLists"):
                listener.exitLists(self)




    def lists(self):

        localctx = myGrammarParser.ListsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_lists)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 24
            self.match(myGrammarParser.LBRACK)
            self.state = 26
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << myGrammarParser.IF) | (1 << myGrammarParser.ELSE) | (1 << myGrammarParser.ELIF) | (1 << myGrammarParser.FOR) | (1 << myGrammarParser.DEF) | (1 << myGrammarParser.LPAREN) | (1 << myGrammarParser.LBRACK) | (1 << myGrammarParser.ID) | (1 << myGrammarParser.NUMBER))) != 0):
                self.state = 25
                self.expression(0)


            self.state = 32
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==myGrammarParser.COMMA:
                self.state = 28
                self.match(myGrammarParser.COMMA)
                self.state = 29
                self.expression(0)
                self.state = 34
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 35
            self.match(myGrammarParser.RBRACK)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class BooleanContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(myGrammarParser.BooleanContext, self).__init__(parent, invokingState)
            self.parser = parser

        def TRUE(self):
            return self.getToken(myGrammarParser.TRUE, 0)

        def FALSE(self):
            return self.getToken(myGrammarParser.FALSE, 0)

        def getRuleIndex(self):
            return myGrammarParser.RULE_boolean

        def enterRule(self, listener):
            if hasattr(listener, "enterBoolean"):
                listener.enterBoolean(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitBoolean"):
                listener.exitBoolean(self)




    def boolean(self):

        localctx = myGrammarParser.BooleanContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_boolean)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 37
            _la = self._input.LA(1)
            if not(_la==myGrammarParser.TRUE or _la==myGrammarParser.FALSE):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ForRuleContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(myGrammarParser.ForRuleContext, self).__init__(parent, invokingState)
            self.parser = parser

        def FOR(self):
            return self.getToken(myGrammarParser.FOR, 0)

        def ID(self):
            return self.getToken(myGrammarParser.ID, 0)

        def IN(self):
            return self.getToken(myGrammarParser.IN, 0)

        def forconstruct(self):
            return self.getTypedRuleContext(myGrammarParser.ForconstructContext,0)


        def getRuleIndex(self):
            return myGrammarParser.RULE_forRule

        def enterRule(self, listener):
            if hasattr(listener, "enterForRule"):
                listener.enterForRule(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitForRule"):
                listener.exitForRule(self)




    def forRule(self):

        localctx = myGrammarParser.ForRuleContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_forRule)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 39
            self.match(myGrammarParser.FOR)
            self.state = 40
            self.match(myGrammarParser.ID)
            self.state = 41
            self.match(myGrammarParser.IN)
            self.state = 42
            self.forconstruct()
            self.state = 43
            self.match(myGrammarParser.COLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ForconstructContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(myGrammarParser.ForconstructContext, self).__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(myGrammarParser.ID, 0)

        def NUMBER(self):
            return self.getToken(myGrammarParser.NUMBER, 0)

        def getRuleIndex(self):
            return myGrammarParser.RULE_forconstruct

        def enterRule(self, listener):
            if hasattr(listener, "enterForconstruct"):
                listener.enterForconstruct(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitForconstruct"):
                listener.exitForconstruct(self)




    def forconstruct(self):

        localctx = myGrammarParser.ForconstructContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_forconstruct)
        try:
            self.state = 52
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [myGrammarParser.ID]:
                self.enterOuterAlt(localctx, 1)
                self.state = 45
                self.match(myGrammarParser.ID)
                pass
            elif token in [myGrammarParser.T__0]:
                self.enterOuterAlt(localctx, 2)
                self.state = 46
                self.match(myGrammarParser.T__0)
                self.state = 47
                self.match(myGrammarParser.ID)
                self.state = 48
                self.match(myGrammarParser.T__1)
                pass
            elif token in [myGrammarParser.T__2]:
                self.enterOuterAlt(localctx, 3)
                self.state = 49
                self.match(myGrammarParser.T__2)
                self.state = 50
                self.match(myGrammarParser.NUMBER)
                self.state = 51
                self.match(myGrammarParser.RPAREN)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class IfRuleContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(myGrammarParser.IfRuleContext, self).__init__(parent, invokingState)
            self.parser = parser

        def IF(self):
            return self.getToken(myGrammarParser.IF, 0)

        def ID(self):
            return self.getToken(myGrammarParser.ID, 0)

        def comp_oper(self):
            return self.getTypedRuleContext(myGrammarParser.Comp_operContext,0)


        def expression(self):
            return self.getTypedRuleContext(myGrammarParser.ExpressionContext,0)


        def ELSE(self):
            return self.getToken(myGrammarParser.ELSE, 0)

        def ELIF(self):
            return self.getToken(myGrammarParser.ELIF, 0)

        def getRuleIndex(self):
            return myGrammarParser.RULE_ifRule

        def enterRule(self, listener):
            if hasattr(listener, "enterIfRule"):
                listener.enterIfRule(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitIfRule"):
                listener.exitIfRule(self)




    def ifRule(self):

        localctx = myGrammarParser.IfRuleContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_ifRule)
        try:
            self.state = 67
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [myGrammarParser.IF]:
                self.enterOuterAlt(localctx, 1)
                self.state = 54
                self.match(myGrammarParser.IF)
                self.state = 55
                self.match(myGrammarParser.ID)
                self.state = 56
                self.comp_oper()
                self.state = 57
                self.expression(0)
                self.state = 58
                self.match(myGrammarParser.COLON)
                pass
            elif token in [myGrammarParser.ELSE]:
                self.enterOuterAlt(localctx, 2)
                self.state = 60
                self.match(myGrammarParser.ELSE)
                self.state = 61
                self.match(myGrammarParser.COLON)
                pass
            elif token in [myGrammarParser.ELIF]:
                self.enterOuterAlt(localctx, 3)
                self.state = 62
                self.match(myGrammarParser.ELIF)
                self.state = 63
                self.match(myGrammarParser.ID)
                self.state = 64
                self.comp_oper()
                self.state = 65
                self.expression(0)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class FunctionDefContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(myGrammarParser.FunctionDefContext, self).__init__(parent, invokingState)
            self.parser = parser

        def DEF(self):
            return self.getToken(myGrammarParser.DEF, 0)

        def ID(self):
            return self.getToken(myGrammarParser.ID, 0)

        def parameters(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(myGrammarParser.ParametersContext)
            else:
                return self.getTypedRuleContext(myGrammarParser.ParametersContext,i)


        def getRuleIndex(self):
            return myGrammarParser.RULE_functionDef

        def enterRule(self, listener):
            if hasattr(listener, "enterFunctionDef"):
                listener.enterFunctionDef(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitFunctionDef"):
                listener.exitFunctionDef(self)




    def functionDef(self):

        localctx = myGrammarParser.FunctionDefContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_functionDef)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 69
            self.match(myGrammarParser.DEF)
            self.state = 70
            self.match(myGrammarParser.ID)
            self.state = 71
            self.match(myGrammarParser.LPAREN)
            self.state = 75
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==myGrammarParser.ID:
                self.state = 72
                self.parameters()
                self.state = 77
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 78
            self.match(myGrammarParser.T__1)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ParametersContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(myGrammarParser.ParametersContext, self).__init__(parent, invokingState)
            self.parser = parser

        def ID(self, i=None):
            if i is None:
                return self.getTokens(myGrammarParser.ID)
            else:
                return self.getToken(myGrammarParser.ID, i)

        def getRuleIndex(self):
            return myGrammarParser.RULE_parameters

        def enterRule(self, listener):
            if hasattr(listener, "enterParameters"):
                listener.enterParameters(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitParameters"):
                listener.exitParameters(self)




    def parameters(self):

        localctx = myGrammarParser.ParametersContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_parameters)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 80
            self.match(myGrammarParser.ID)
            self.state = 85
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==myGrammarParser.COMMA:
                self.state = 81
                self.match(myGrammarParser.COMMA)
                self.state = 82
                self.match(myGrammarParser.ID)
                self.state = 87
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ComparisonContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(myGrammarParser.ComparisonContext, self).__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(myGrammarParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(myGrammarParser.ExpressionContext,i)


        def comp_oper(self):
            return self.getTypedRuleContext(myGrammarParser.Comp_operContext,0)


        def comparison(self):
            return self.getTypedRuleContext(myGrammarParser.ComparisonContext,0)


        def getRuleIndex(self):
            return myGrammarParser.RULE_comparison

        def enterRule(self, listener):
            if hasattr(listener, "enterComparison"):
                listener.enterComparison(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitComparison"):
                listener.exitComparison(self)




    def comparison(self):

        localctx = myGrammarParser.ComparisonContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_comparison)
        try:
            self.state = 96
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 88
                self.expression(0)
                self.state = 89
                self.comp_oper()
                self.state = 90
                self.expression(0)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 92
                self.match(myGrammarParser.LPAREN)
                self.state = 93
                self.comparison()
                self.state = 94
                self.match(myGrammarParser.RPAREN)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Comp_operContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(myGrammarParser.Comp_operContext, self).__init__(parent, invokingState)
            self.parser = parser

        def GT(self):
            return self.getToken(myGrammarParser.GT, 0)

        def GE(self):
            return self.getToken(myGrammarParser.GE, 0)

        def LT(self):
            return self.getToken(myGrammarParser.LT, 0)

        def LE(self):
            return self.getToken(myGrammarParser.LE, 0)

        def EQUAL(self):
            return self.getToken(myGrammarParser.EQUAL, 0)

        def NOTEQUAL(self):
            return self.getToken(myGrammarParser.NOTEQUAL, 0)

        def getRuleIndex(self):
            return myGrammarParser.RULE_comp_oper

        def enterRule(self, listener):
            if hasattr(listener, "enterComp_oper"):
                listener.enterComp_oper(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitComp_oper"):
                listener.exitComp_oper(self)




    def comp_oper(self):

        localctx = myGrammarParser.Comp_operContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_comp_oper)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 98
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << myGrammarParser.GT) | (1 << myGrammarParser.GE) | (1 << myGrammarParser.LT) | (1 << myGrammarParser.LE) | (1 << myGrammarParser.EQUAL) | (1 << myGrammarParser.NOTEQUAL))) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class RulesContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(myGrammarParser.RulesContext, self).__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(myGrammarParser.EOF, 0)

        def statement(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(myGrammarParser.StatementContext)
            else:
                return self.getTypedRuleContext(myGrammarParser.StatementContext,i)


        def getRuleIndex(self):
            return myGrammarParser.RULE_rules

        def enterRule(self, listener):
            if hasattr(listener, "enterRules"):
                listener.enterRules(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitRules"):
                listener.exitRules(self)




    def rules(self):

        localctx = myGrammarParser.RulesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_rules)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 101 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 100
                self.statement()
                self.state = 103 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << myGrammarParser.IF) | (1 << myGrammarParser.ELSE) | (1 << myGrammarParser.ELIF) | (1 << myGrammarParser.FOR) | (1 << myGrammarParser.DEF) | (1 << myGrammarParser.LPAREN) | (1 << myGrammarParser.LBRACK) | (1 << myGrammarParser.ID) | (1 << myGrammarParser.NUMBER) | (1 << myGrammarParser.NEWLINE))) != 0)):
                    break

            self.state = 105
            self.match(myGrammarParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ExpressionContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(myGrammarParser.ExpressionContext, self).__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(myGrammarParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(myGrammarParser.ExpressionContext,i)


        def lists(self):
            return self.getTypedRuleContext(myGrammarParser.ListsContext,0)


        def NUMBER(self):
            return self.getToken(myGrammarParser.NUMBER, 0)

        def ID(self):
            return self.getToken(myGrammarParser.ID, 0)

        def functionDef(self):
            return self.getTypedRuleContext(myGrammarParser.FunctionDefContext,0)


        def forRule(self):
            return self.getTypedRuleContext(myGrammarParser.ForRuleContext,0)


        def ifRule(self):
            return self.getTypedRuleContext(myGrammarParser.IfRuleContext,0)


        def POWER(self):
            return self.getToken(myGrammarParser.POWER, 0)

        def MULTIPLY(self):
            return self.getToken(myGrammarParser.MULTIPLY, 0)

        def DIVIDE(self):
            return self.getToken(myGrammarParser.DIVIDE, 0)

        def PLUS(self):
            return self.getToken(myGrammarParser.PLUS, 0)

        def MINUS(self):
            return self.getToken(myGrammarParser.MINUS, 0)

        def getRuleIndex(self):
            return myGrammarParser.RULE_expression

        def enterRule(self, listener):
            if hasattr(listener, "enterExpression"):
                listener.enterExpression(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitExpression"):
                listener.exitExpression(self)



    def expression(self, _p=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = myGrammarParser.ExpressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 20
        self.enterRecursionRule(localctx, 20, self.RULE_expression, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 118
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [myGrammarParser.LPAREN]:
                self.state = 108
                self.match(myGrammarParser.LPAREN)
                self.state = 109
                self.expression(0)
                self.state = 110
                self.match(myGrammarParser.RPAREN)
                pass
            elif token in [myGrammarParser.LBRACK]:
                self.state = 112
                self.lists()
                pass
            elif token in [myGrammarParser.NUMBER]:
                self.state = 113
                self.match(myGrammarParser.NUMBER)
                pass
            elif token in [myGrammarParser.ID]:
                self.state = 114
                self.match(myGrammarParser.ID)
                pass
            elif token in [myGrammarParser.DEF]:
                self.state = 115
                self.functionDef()
                pass
            elif token in [myGrammarParser.FOR]:
                self.state = 116
                self.forRule()
                pass
            elif token in [myGrammarParser.IF, myGrammarParser.ELSE, myGrammarParser.ELIF]:
                self.state = 117
                self.ifRule()
                pass
            else:
                raise NoViableAltException(self)

            self._ctx.stop = self._input.LT(-1)
            self.state = 131
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,10,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 129
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,9,self._ctx)
                    if la_ == 1:
                        localctx = myGrammarParser.ExpressionContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 120
                        if not self.precpred(self._ctx, 9):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 9)")
                        self.state = 121
                        self.match(myGrammarParser.POWER)
                        self.state = 122
                        self.expression(10)
                        pass

                    elif la_ == 2:
                        localctx = myGrammarParser.ExpressionContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 123
                        if not self.precpred(self._ctx, 8):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 8)")
                        self.state = 124
                        _la = self._input.LA(1)
                        if not(_la==myGrammarParser.MULTIPLY or _la==myGrammarParser.DIVIDE):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 125
                        self.expression(9)
                        pass

                    elif la_ == 3:
                        localctx = myGrammarParser.ExpressionContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 126
                        if not self.precpred(self._ctx, 7):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 7)")
                        self.state = 127
                        _la = self._input.LA(1)
                        if not(_la==myGrammarParser.PLUS or _la==myGrammarParser.MINUS):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 128
                        self.expression(8)
                        pass

             
                self.state = 133
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,10,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class StatementContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(myGrammarParser.StatementContext, self).__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(myGrammarParser.ID, 0)

        def expression(self):
            return self.getTypedRuleContext(myGrammarParser.ExpressionContext,0)


        def NEWLINE(self):
            return self.getToken(myGrammarParser.NEWLINE, 0)

        def functionDef(self):
            return self.getTypedRuleContext(myGrammarParser.FunctionDefContext,0)


        def getRuleIndex(self):
            return myGrammarParser.RULE_statement

        def enterRule(self, listener):
            if hasattr(listener, "enterStatement"):
                listener.enterStatement(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitStatement"):
                listener.exitStatement(self)




    def statement(self):

        localctx = myGrammarParser.StatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_statement)
        try:
            self.state = 145
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,11,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 134
                self.match(myGrammarParser.ID)
                self.state = 135
                self.match(myGrammarParser.ASSIGNMENT)
                self.state = 136
                self.expression(0)
                self.state = 137
                self.match(myGrammarParser.NEWLINE)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 139
                self.expression(0)
                self.state = 140
                self.match(myGrammarParser.NEWLINE)
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 142
                self.expression(0)
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 143
                self.functionDef()
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 144
                self.match(myGrammarParser.NEWLINE)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx, ruleIndex, predIndex):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[10] = self.expression_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expression_sempred(self, localctx, predIndex):
            if predIndex == 0:
                return self.precpred(self._ctx, 9)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 8)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 7)
         




