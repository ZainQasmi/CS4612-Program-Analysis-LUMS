Assignment submitted by:
Ali Ahsan, 18100071
Zain Qasmi, 18100276


Grammar defined for Python2 language.