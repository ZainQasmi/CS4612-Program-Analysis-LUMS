# Generated from myGrammar.g4 by ANTLR 4.7
from antlr4 import *

# This class defines a complete listener for a parse tree produced by myGrammarParser.
class myGrammarListener(ParseTreeListener):

    # Enter a parse tree produced by myGrammarParser#lists.
    def enterLists(self, ctx):
        pass

    # Exit a parse tree produced by myGrammarParser#lists.
    def exitLists(self, ctx):
        pass


    # Enter a parse tree produced by myGrammarParser#boolean.
    def enterBoolean(self, ctx):
        pass

    # Exit a parse tree produced by myGrammarParser#boolean.
    def exitBoolean(self, ctx):
        pass


    # Enter a parse tree produced by myGrammarParser#forRule.
    def enterForRule(self, ctx):
        pass

    # Exit a parse tree produced by myGrammarParser#forRule.
    def exitForRule(self, ctx):
        pass


    # Enter a parse tree produced by myGrammarParser#forconstruct.
    def enterForconstruct(self, ctx):
        pass

    # Exit a parse tree produced by myGrammarParser#forconstruct.
    def exitForconstruct(self, ctx):
        pass


    # Enter a parse tree produced by myGrammarParser#ifRule.
    def enterIfRule(self, ctx):
        pass

    # Exit a parse tree produced by myGrammarParser#ifRule.
    def exitIfRule(self, ctx):
        pass


    # Enter a parse tree produced by myGrammarParser#functionDef.
    def enterFunctionDef(self, ctx):
        pass

    # Exit a parse tree produced by myGrammarParser#functionDef.
    def exitFunctionDef(self, ctx):
        pass


    # Enter a parse tree produced by myGrammarParser#parameters.
    def enterParameters(self, ctx):
        pass

    # Exit a parse tree produced by myGrammarParser#parameters.
    def exitParameters(self, ctx):
        pass


    # Enter a parse tree produced by myGrammarParser#comparison.
    def enterComparison(self, ctx):
        pass

    # Exit a parse tree produced by myGrammarParser#comparison.
    def exitComparison(self, ctx):
        pass


    # Enter a parse tree produced by myGrammarParser#comp_oper.
    def enterComp_oper(self, ctx):
        pass

    # Exit a parse tree produced by myGrammarParser#comp_oper.
    def exitComp_oper(self, ctx):
        pass


    # Enter a parse tree produced by myGrammarParser#rules.
    def enterRules(self, ctx):
        pass

    # Exit a parse tree produced by myGrammarParser#rules.
    def exitRules(self, ctx):
        pass


    # Enter a parse tree produced by myGrammarParser#expression.
    def enterExpression(self, ctx):
        pass

    # Exit a parse tree produced by myGrammarParser#expression.
    def exitExpression(self, ctx):
        pass


    # Enter a parse tree produced by myGrammarParser#statement.
    def enterStatement(self, ctx):
        pass

    # Exit a parse tree produced by myGrammarParser#statement.
    def exitStatement(self, ctx):
        pass


